import {createContext} from "react";

const CartContext = createContext<any>([]);

export default CartContext;
