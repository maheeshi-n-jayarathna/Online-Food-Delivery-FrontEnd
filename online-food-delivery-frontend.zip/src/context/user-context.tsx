import {createContext} from "react";

const UserContext = createContext<any>([]);

export default UserContext;
