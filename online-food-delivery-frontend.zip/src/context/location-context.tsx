import {createContext} from "react";

const LocationContext = createContext<any>([]);

export default LocationContext;