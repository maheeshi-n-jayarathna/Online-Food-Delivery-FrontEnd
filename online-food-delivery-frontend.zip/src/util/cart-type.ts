export type CartItemType = {
    id:string
    image: string,
    name: string,
    description: string,
    price: number,
    qtyOnStock: number,
    qty:number
}