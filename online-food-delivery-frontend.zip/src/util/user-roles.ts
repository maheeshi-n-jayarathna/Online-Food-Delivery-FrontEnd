export enum UserRoles  {
    ADMIN,
    DRIVER,
    SELLER,
    CUSTOMER,
    GUEST
}
