import "../../index.css";
import Header from "./header.tsx";
import {ReactNode} from "react";

export default function ({children}: { children: ReactNode }): JSX.Element {
    return (
        <div>
            <Header/>
            <div className="py-[65px] max-w-4xl mx-auto ">
                {
                    children
                }
            </div>
            <footer className="border-t p-8 text-center text-gray-500 mt-16">
                &copy; 2023 All rights reserved
            </footer>
        </div>
    );
}
