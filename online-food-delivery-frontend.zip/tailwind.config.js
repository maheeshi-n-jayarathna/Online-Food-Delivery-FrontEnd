/** @type {import('tailwindcss').Config} */
module.exports = {
    content: [
        "./index.html",
        "./src/**/*.{js,ts,jsx,tsx}",
    ],
    theme: {
        extend: {
            colors: {
                'primary': '#f13a01',
                'primary-50': '#fff5ec',
                'primary-100': '#ffe8d3',
                'primary-200': '#ffcea6',
                'primary-300': '#ffab6d',
                'primary-400': '#ff7c33',
                'primary-500': '#ff570b',
                'primary-600': '#f13a01',
                'primary-700': '#cb2803',
                'primary-800': '#a1210b',
                'primary-900': '#811e0d',
                'primary-950': '#460b04',
            },
            backgroundColor: {
                primary: '#f13a01',
                'primary-50': '#fff5ec',
                'primary-100': '#ffe8d3',
                'primary-200': '#ffcea6',
                'primary-300': '#ffab6d',
                'primary-400': '#ff7c33',
                'primary-500': '#ff570b',
                'primary-600': '#f13a01',
                'primary-700': '#cb2803',
                'primary-800': '#a1210b',
                'primary-900': '#811e0d',
                'primary-950': '#460b04',
            },

        },
    },
    plugins: [],
}
